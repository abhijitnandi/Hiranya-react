export const APIURL = "https://devforall.website/dev/hiranya/api/";
export const SITEURL = "https://devforall.website/dev/hiranya/";